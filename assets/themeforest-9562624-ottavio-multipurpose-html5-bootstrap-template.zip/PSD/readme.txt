Ottavio - Creative Multi-Purpose PSD Template

PLEASE don�t forget to rate it.
Thanks so much!

---------------------------------

Template Features:

- 30 Fully Layered Adobe Photoshop PSD files
- 6 PSD files for your online store
- 7 Portfolio page templates
- Awesome blog sections
- Bootstrap Grid 1170px
- Ultra modern & elegant design
- Fully customizable
- Well Organized Layers (created with Adobe Photoshop CS5)
- Free Google Fonts used

---------------------------------

Free Google Fonts Used:
https://www.google.com/fonts/specimen/Raleway
https://www.google.com/fonts/specimen/Montserrat
https://www.google.com/fonts/specimen/Open+Sans

---------------------------------

Icon Font:
http://fortawesome.github.io/Font-Awesome/

---------------------------------

Graphics Used:
https://www.flickr.com/
http://www.shutterstock.com
http://www.fotolia.com

NOTE: Images used in the preview are not included in PSD file

---------------------------------

Levels & Groups
Each PSD Files has levels well organized and structured in groups. For example

- Header
- Section
- Separator
- Section
- Separator
- ..
- ..
- ..
- Footer

---------------------------------

File Structure

- Home page
	1 � Home page.psd

- About alternative pages
	2 � About us.psd
	3 � About us 2.psd
	4 � About us 3.psd
	5 � About me.psd
	6 � About me 2.psd

- Service alternative pages
	7 � Service.psd
	8 � Service 2.psd

- Blog page alternative pages
	9 � Blog list.psd
	10 � Blog Masonry.psd
	11 � Blog Details.psd

- Portfolio alternative pages
	12 � Portfolio grid.psd
	13 � Portfolio grid 2.psd
	14 � Portfolio grid 3.psd
	15 � Portfolio list fullscreen.psd
	16 � Portfolio detail.psd
	17 � Portfolio detail + sidebar.psd
	18 � Portfolio detail + sidebar 2.psd

- E-shop pages
	19 � Eshop Landing page.psd
	20 � Eshop Product list.psd
	21 � Eshop Product list + sidebar.psd
	22 � Eshop product page.psd
	23 � Eshop cart.psd
	24 � Eshop checkout.psd

- Contact alternative pages
	25 � Contact us.psd
	26 � Contact us 2.psd
	27 � Contact us 3.psd

Other pages
	28 � Pricing table.psd
	29 � Search.psd
	30 � Faq.psd

